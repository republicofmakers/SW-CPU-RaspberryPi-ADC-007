#!/usr/bin/env python3
import time
from smbus import SMBus

I2C_BUS = 1
ADS1115_ADDR = 0x48  # if ADDR=GND

# ADS1115 registers
REG_CONVERSION = 0x00
REG_CONFIG     = 0x01

# Build a config word for single-shot read of a given channel (0..3)
# Settings:
# - Single-shot mode
# - MUX: AINx vs GND (single-ended)
# - PGA: +/- 4.096 V (1 bit = 125 uV) — good for up to ~3.3 V inputs
# - Data rate: 128 SPS
# - Comparator disabled
def make_config(channel):
    assert 0 <= channel <= 3
    mux_map = {0: 0b100, 1: 0b101, 2: 0b110, 3: 0b111}

    OS      = 0b1 << 15                     # start single conversion
    MUX     = mux_map[channel] << 12        # AINx vs GND
    PGA     = 0b001 << 9                    # ±4.096 V
    MODE    = 0b1 << 8                      # single-shot
    DR      = 0b100 << 5                    # 128 SPS
    COMP    = 0b011                         # disable comparator (bits[3:0]=0011, active-high, non-latching, disabled)

    cfg = OS | MUX | PGA | MODE | DR | COMP
    return cfg

def write_config(bus, cfg):
    # ADS1115 expects big-endian
    bus.write_i2c_block_data(ADS1115_ADDR, REG_CONFIG, [(cfg >> 8) & 0xFF, cfg & 0xFF])

def read_conversion(bus):
    data = bus.read_i2c_block_data(ADS1115_ADDR, REG_CONVERSION, 2)
    raw = (data[0] << 8) | data[1]
    # signed 16-bit
    if raw & 0x8000:
        raw -= 1 << 16
    return raw

def read_channel(bus, ch):
    cfg = make_config(ch)
    write_config(bus, cfg)

    # Wait until conversion ready: typical at 128SPS ~7.8ms; we poll OS bit
    # Quick, reliable sleep:
    time.sleep(0.009)

    raw = read_conversion(bus)
    # LSB size at ±4.096 V range = 125 µV
    volts = raw * 0.000125
    return raw, volts

def main():
    bus = SMBus(I2C_BUS)
    try:
        while True:
            readings = []
            for ch in range(4):
                raw, v = read_channel(bus, ch)
                readings.append(v)
            print(f"A0={readings[0]:.4f} V  A1={readings[1]:.4f} V  A2={readings[2]:.4f} V  A3={readings[3]:.4f} V")
            time.sleep(0.2)
    except KeyboardInterrupt:
        pass
    finally:
        bus.close()

if __name__ == "__main__":
    main()
